﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_LightBeam.BP_LightBeam_C.Init
struct ABP_LightBeam_C_Init_Params
{
};

// Function BP_LightBeam.BP_LightBeam_C.ReceiveBeginPlay
struct ABP_LightBeam_C_ReceiveBeginPlay_Params
{
};

// Function BP_LightBeam.BP_LightBeam_C.EditorInit
struct ABP_LightBeam_C_EditorInit_Params
{
};

// Function BP_LightBeam.BP_LightBeam_C.ExecuteUbergraph_BP_LightBeam
struct ABP_LightBeam_C_ExecuteUbergraph_BP_LightBeam_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
