﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass CustomScrollVertical_WidgetBP.CustomScrollVertical_WidgetBP_C
// 0x0000 (FullSize[0x03B0] - InheritedSize[0x03B0])
class UCustomScrollVertical_WidgetBP_C : public UPortalWarsCustomScrollWidget
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("WidgetBlueprintGeneratedClass CustomScrollVertical_WidgetBP.CustomScrollVertical_WidgetBP_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
