﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass EMPGrenadePickup_BP.EMPGrenadePickup_BP_C
// 0x0000 (FullSize[0x0270] - InheritedSize[0x0270])
class AEMPGrenadePickup_BP_C : public APortalWarsGrenadePickup
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass EMPGrenadePickup_BP.EMPGrenadePickup_BP_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
