﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass BPProgressionIcon_WidgetBP.BPProgressionIcon_WidgetBP_C
// 0x0000 (FullSize[0x0270] - InheritedSize[0x0270])
class UBPProgressionIcon_WidgetBP_C : public UPortalWarsProgressionIconWidget
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("WidgetBlueprintGeneratedClass BPProgressionIcon_WidgetBP.BPProgressionIcon_WidgetBP_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
