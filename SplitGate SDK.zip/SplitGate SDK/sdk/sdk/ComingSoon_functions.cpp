﻿// Name: PortalWars, Version: 1.0

#include "..\..\pch.h"

/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	//---------------------------------------------------------------------------
	// Functions
	//---------------------------------------------------------------------------

	// Function ComingSoon.ComingSoon_C.PreConstruct
	// (BlueprintCosmetic, Event, Public, BlueprintEvent)
	// Parameters:
	// bool                           IsDesignTime                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	//void UComingSoon_C::PreConstruct(bool IsDesignTime)
	//{
	//	static auto fn = UObject::FindObject<UFunction>("Function ComingSoon.ComingSoon_C.PreConstruct");
	//
	//	UComingSoon_C_PreConstruct_Params params;
	//	params.IsDesignTime = IsDesignTime;
	//
	//	auto flags = fn->FunctionFlags;
	//
	//	UObject::ProcessEvent(fn, &params);
	//	fn->FunctionFlags = flags;
	//
	//}
	//
	//
	//// Function ComingSoon.ComingSoon_C.ExecuteUbergraph_ComingSoon
	//// (Final)
	//// Parameters:
	//// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	//void UComingSoon_C::ExecuteUbergraph_ComingSoon(int EntryPoint)
	//{
	//	static auto fn = UObject::FindObject<UFunction>("Function ComingSoon.ComingSoon_C.ExecuteUbergraph_ComingSoon");
	//
	//	UComingSoon_C_ExecuteUbergraph_ComingSoon_Params params;
	//	params.EntryPoint = EntryPoint;
	//
	//	auto flags = fn->FunctionFlags;
	//
	//	UObject::ProcessEvent(fn, &params);
	//	fn->FunctionFlags = flags;
	//
	//}
	//
	//
	//void UComingSoon_C::AfterRead()
	//{
	//	UPortalWarsMenuWidget::AfterRead();
	//
	//	READ_PTR_FULL(ErrorText, UTextBlock);
	//	READ_PTR_FULL(MenuBackground, UMenuBackground_C);
	//}
	//
	//void UComingSoon_C::BeforeDelete()
	//{
	//	UPortalWarsMenuWidget::BeforeDelete();
	//
	//	DELE_PTR_FULL(ErrorText);
	//	DELE_PTR_FULL(MenuBackground);
	//}
	//
	//}
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
