﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ChallengeInspectEntry_WidgetBP.ChallengeInspectEntry_WidgetBP_C.RefreshEntry_BP
struct UChallengeInspectEntry_WidgetBP_C_RefreshEntry_BP_Params
{
};

// Function ChallengeInspectEntry_WidgetBP.ChallengeInspectEntry_WidgetBP_C.ExecuteUbergraph_ChallengeInspectEntry_WidgetBP
struct UChallengeInspectEntry_WidgetBP_C_ExecuteUbergraph_ChallengeInspectEntry_WidgetBP_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
