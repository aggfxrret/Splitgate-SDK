﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function B_Spline_Impact_Road.B_Spline_Impact_Road_C.Init
struct AB_Spline_Impact_Road_C_Init_Params
{
};

// Function B_Spline_Impact_Road.B_Spline_Impact_Road_C.ReceiveBeginPlay
struct AB_Spline_Impact_Road_C_ReceiveBeginPlay_Params
{
};

// Function B_Spline_Impact_Road.B_Spline_Impact_Road_C.EditorInit
struct AB_Spline_Impact_Road_C_EditorInit_Params
{
};

// Function B_Spline_Impact_Road.B_Spline_Impact_Road_C.ExecuteUbergraph_B_Spline_Impact_Road
struct AB_Spline_Impact_Road_C_ExecuteUbergraph_B_Spline_Impact_Road_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
