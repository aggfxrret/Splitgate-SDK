﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass CustomGameCreatedBy_WidgetBP.CustomGameCreatedBy_WidgetBP_C
// 0x0000 (FullSize[0x0630] - InheritedSize[0x0630])
class UCustomGameCreatedBy_WidgetBP_C : public UPortalWarsPlayerEntryWidget
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("WidgetBlueprintGeneratedClass CustomGameCreatedBy_WidgetBP.CustomGameCreatedBy_WidgetBP_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
