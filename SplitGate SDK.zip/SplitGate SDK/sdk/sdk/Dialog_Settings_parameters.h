﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Dialog_Settings.Dialog_Settings_C.GetWidgetToFocus
struct UDialog_Settings_C_GetWidgetToFocus_Params
{
	class UWidget*                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function Dialog_Settings.Dialog_Settings_C.BndEvt__Settings_WidgetBP_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
struct UDialog_Settings_C_BndEvt__Settings_WidgetBP_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature_Params
{
};

// Function Dialog_Settings.Dialog_Settings_C.Construct
struct UDialog_Settings_C_Construct_Params
{
};

// Function Dialog_Settings.Dialog_Settings_C.Destruct
struct UDialog_Settings_C_Destruct_Params
{
};

// Function Dialog_Settings.Dialog_Settings_C.ExecuteUbergraph_Dialog_Settings
struct UDialog_Settings_C_ExecuteUbergraph_Dialog_Settings_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
