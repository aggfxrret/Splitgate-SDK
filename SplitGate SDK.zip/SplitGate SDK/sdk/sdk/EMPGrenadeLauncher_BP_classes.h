﻿#pragma once

#include "..\..\pch.h"


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass EMPGrenadeLauncher_BP.EMPGrenadeLauncher_BP_C
// 0x0000 (FullSize[0x06C8] - InheritedSize[0x06C8])
class AEMPGrenadeLauncher_BP_C : public AGrenadeLauncher
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass EMPGrenadeLauncher_BP.EMPGrenadeLauncher_BP_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
